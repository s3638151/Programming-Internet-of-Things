project\_constant module
========================

.. automodule:: project_constant
   :members:
   :undoc-members:
   :show-inheritance:
