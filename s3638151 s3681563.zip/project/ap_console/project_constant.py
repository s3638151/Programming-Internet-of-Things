#!/usr/bin/python
# -*- coding: UTF-8 -*-

from const import Const

ProjectConst = Const()

#MP listener IP and port
ProjectConst.ListenerIP = "127.0.0.1"
ProjectConst.ListenerPort = 12345

