const module
============

.. automodule:: const
   :members:
   :undoc-members:
   :show-inheritance:
