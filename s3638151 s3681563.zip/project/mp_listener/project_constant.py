#!/usr/bin/python
# -*- coding: UTF-8 -*-

from const import Const

ProjectConst = Const()

#MP listener IP and port
ProjectConst.ListenerIP = "0.0.0.0"
ProjectConst.ListenerPort = 12345
ProjectConst.CLOUD_API_URL = "http://localhost:55555/"

